import React from 'react'
import ReactDOM from 'react-dom/client'
import { HashRouter } from 'react-router-dom'
import App from './App'
import { ScanStoreProvider } from './lib/store'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <HashRouter>
      <ScanStoreProvider>
        <App />
      </ScanStoreProvider>
    </HashRouter>
  </React.StrictMode>,
)
